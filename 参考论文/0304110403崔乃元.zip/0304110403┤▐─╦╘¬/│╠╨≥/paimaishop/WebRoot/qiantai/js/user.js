/**
 * Created by ideabobo on 14-6-28.
 */

/***************************************用户模块*******************************************/

var userinfo = null;
function login(uinfo){
    var fdata = uinfo || serializeObject($("#loginform"));
    if($.trim(fdata.username)=="" || $.trim(fdata.passwd) == ""){
        showLoader("请输入用户名或密码！",true);
        return;
    }
    ajaxCallback("login",fdata,function(data){
       if(data.info && data.info=="fail"){
           showLoader("用户名或密码错误",true);
           changePage("loginpage");
       }else{
           showLoader("登陆成功!",true);
           userinfo = data;
           $("#youke").hide();
           $("#vip").show();
           $("#welcom").text("欢迎你:"+userinfo.username);
           localStorage['userinfo'] = JSON.stringify(userinfo);
           toMain();
       }
    });
}

function logout(){
    userinfo = null;
    toLogin();
    ajaxCallback("clearSession",{},function(data){

    });
}

function toRegister(){
    changePage("registerpage");
}

function toLogin(){
    //$($(':input','#loginform').get(1)).val("");
    $("#youke").show();
    $("#vip").hide();
    changePage("loginpage");
}

function register(){

    var fdata = serializeObject($("#registerform"));
    if($.trim(fdata.username) == "" || $.trim(fdata.passwd) == "" || $.trim(fdata.tel) == ""){
        showLoader("请填写完整信息!",true);
        return;
    }
    if(fdata.tel.length<11){
        showLoader("电话号码格式不对!",true);
        return;
    }
    if(fdata.passwd != fdata.passwd2){
        showLoader("两次密码不一致!",true);
        return;
    }
    //uplaodImg(function(r){
        //fdata.img = r;
        ajaxCallback("checkUser",fdata,function(d){
            if(d.info == "success"){
                ajaxCallback("register",fdata,function(r){
                    if(r.info=="success"){
                        showLoader("注册成功!",true);
                        toLogin();
                    }else{
                        showLoader("注册失败请稍候再试!",true);
                    }
                });
            }else{
                showLoader("用户名已存在!",true);
            }
        });
    //});

}

function myinfo(){
    if(userinfo){
        changePage("userinfopage");
        $("#vusername").val(userinfo.username);
        $("#vtel").val(userinfo.tel);
        $("#vqq").val(userinfo.qq);
        //$("#vwechat").val(userinfo.wechat);
        $("#vsid").val(userinfo.sid);
        $("#vbirth").val(userinfo.birth);
        $("#vemail").val(userinfo.email);
        $("#vpasswd").val(userinfo.passwd);
        $("#vaddress").val(userinfo.address);
    }else{
        changePage("loginpage");
    }

}

function editUserInfo(){
    $("#editbutton").show();
}

function updateUserInfo(){
    var fdata = serializeObject($("#userform"));
    fdata.id = userinfo.id;
    ajaxCallback("updateUser",fdata,function(r){
        if(r.info == "success"){
            showLoader("保存成功!",true);
            userinfo.qq = fdata.qq;
            userinfo.tel = fdata.tel;
            userinfo.wechat = fdata.wechat;
            userinfo.email = fdata.email;
            userinfo.birth = fdata.birth;
            userinfo.sex = fdata.sex;
        }else{
            showLoader("保存失败,请稍候再试!",true);
        }
    });
}

function toChangePasswd(){
    $("#pusername").text("用户名:"+userinfo.username);
    changePage("passwdpage");
}

function changePasswd(){
    var fdata = serializeObject($("#passwdform"));
    fdata.id = userinfo.id;
    if(fdata.oldpasswd != userinfo.passwd){
        showLoader("原始密码错误！",true);
        return;
    }
    if($.trim(fdata.passwd) == ""){
        showLoader("密码不能为空！",true);
        return;
    }
    if(fdata.passwd != fdata.passwd2){
        showLoader("两次密码不一致！",true);
        return;
    }
    ajaxCallback("changePasswd",fdata,function(r){
        if(r.info == "success"){
            showLoader("保存成功!",true);
        }else{
            showLoader("保存失败,请稍候再试!",true);
        }
    });
}

$(function(){
    ajaxCallback("checkSession",{},function(data){
        if(data.username){
            userinfo = data;
            $("#youke").hide();
            $("#vip").show();
            $("#welcom").text("欢迎你:"+userinfo.username);
            localStorage['userinfo'] = JSON.stringify(userinfo);
        }
    });
});

/***************************************用户模块*******************************************/




