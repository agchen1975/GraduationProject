/**
 * Created by ideabobo on 14-6-28.
 */

var rootUrl = "http://localhost:8080/shopwebsite/";
var fileurl = rootUrl+"upload/";
var clientUrl = rootUrl+"Wehall!";