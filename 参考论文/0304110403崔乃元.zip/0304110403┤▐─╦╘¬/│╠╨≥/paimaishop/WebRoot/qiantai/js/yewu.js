/**
 * Created by Bowa on 2014/8/28.
 */
var shoplist = [];
var goodlist = [];
var noticelist = [];
var focusobj = null;
var focushop = null;
var gouwuche = "gouwuche";
var totalprice = 0;

$(function(){
//设置类别列表
    var p = {};
    p.tpl = '<li onclick="toGood(%s);"><img src="'+fileurl+'%s">'+
                '<h1>%s</h1><p>¥%s</p>'+
            '</li>';
    p.colums = ["id","img","gname","price"];
    $("#jlist").data("property",JSON.stringify(p));


    var p2 = {};
    p2.tpl = '<li onclick="noticeDetail(%s)">%s<span>%s</span></li>';
    p2.colums = ["id","title","ndate"];
    $("#notelist").data("property",JSON.stringify(p2));

    var p3 = {};
    p3.tpl = '<li onclick="billDetail(%s)">%s&nbsp;&nbsp;&nbsp;&nbsp;%s&nbsp;&nbsp;&nbsp;&nbsp;价格:%s元&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:tuiding(%s);" style="color: blue;">退订</a></li>';
    p3.colums = ["id","gnames","ndate","price","id"];
    $("#bills").data("property",JSON.stringify(p3));

    var p4 = {};
    p4.tpl = '<li onclick="refreshGood(\'\',%s)">%s</li>';
    p4.colums = ["id","title"];
    $("#typelist").data("property",JSON.stringify(p4));



    $("#youke").show();
    $("#vip").hide();

    toMain();
});

function toMain(){
    changePage("mainpage");
    $("#flashbox").show();
    listType();
    listGood();
}

function listShop(){
    ajaxCallback("listShop",{},function(data){
        shoplist = data;
        $("#shops").refreshShowListView(data);
    });
}

function toShop(id){
    for(var i=0;i<shoplist.length;i++){
        if(shoplist[i].id == id){
            focushop = shoplist[i];
            break;
        }
    }
    toGoods(id)
}

function toGoods(id){
    //var sid = id || "";
    //changePage("goodspage");
    //listType();
    //listGood(sid);
    toMain();
    $("#flashbox").hide();
}

function search(){
    var title = $("#searchKey").val();
    toGoods();
    var type = "";
    refreshGood(title,type);
}

function refreshGood(title,type){
    var stype = type || "";
    ajaxCallback("listGood",{stitle:title,stype:stype},function(data){
        $("#jlist").refreshShowListView(data);
    });
}

function listGood(){
    ajaxCallback("listGood",{},function(data){
        goodlist = data;
        $("#jlist").refreshShowListView(data);
    });
}

function listType(){
    ajaxCallback("listType",{},function(data){
        $("#typelist").refreshShowListView(data);
    });
}

function toGood(id){
    var obj = getGoodById(id);
    focusobj = obj;
    changePage("goodpage");
    $("#gname2").text(obj.gname);
    $("#gimg2").attr("src",fileurl+obj.img);
    $("#gnote2").text(obj.note);
    $("#yuanjia").text("原价:"+obj.price+"元");
    var zhekou = (obj.sale && parseFloat(obj.sale)) || 1;
    focusobj.price = (obj.price*zhekou).toFixed(1);
    $("#gprice2").text("¥"+focusobj.price);

    listReplay();
}
function toHalf(el){
    if(el.checked){
        $("#gprice2").text("¥"+focusobj.price/2);
        totalprice = focusobj.price/2;
    }else{
        $("#gprice2").text("¥"+focusobj.price);
        totalprice = focusobj.price;
    };
}
function listReplay(){
    ajaxCallback("listReplay",{pid:focusobj.id},function(data){
        $("#replays").refreshShowListView(data);
    });
}
function addReplay(){
    var note = $("#rnote").val();
    ajaxCallback("addReplay",{pid:focusobj.id,uid:userinfo.id,username:userinfo.username,note:note},function(data){
        listReplay();
    });
}

function getGoodById(id){
    for(var i=0;i<goodlist.length;i++){
        var good = goodlist[i];
        if(good.id == id){
            return good;
        }
    }
    return null;
}

function tijiaouser(){
    var note = $("#infobeizhu2").val();
    var bill = {};
    bill.uid = userinfo.id;
    bill.user = userinfo.username;
    bill.shop = "";
    bill.sid = "";
    bill.gids = focusobj.id;
    bill.gnames = focusobj.gname;
    bill.total = focusobj.price;
    bill.tel = userinfo.tel;
    bill.address = userinfo.address;
    bill.note = note;
    ajaxCallback("saveBill",bill,function(){
        showLoader("竞价提交成功!",true);
        showTipTimer("竞价提交成功!",function(){
            toMyBill();
        });

    });
}

function tijiao(){
    if(userinfo){
        changePage("infopage2");
        $("#iscar2").val("1");
    }else{
        changePage("infopage");
        $("#iscar").val("1");
    }
}

function yuding(){
    if(userinfo){
        var bill = {};
        bill.shop = "";
        bill.sid = "";
        bill.gids = focusobj.id;
        bill.gnames = focusobj.gname;
        bill.total = totalprice;
        bill.tel = userinfo.tel;
        bill.address = userinfo.address;
        bill.uid = userinfo.id;
        bill.user = userinfo.username;
        bill.price = totalprice;
        $("#billtitle").text(bill.gnames);
        $("#billprice").text(focusobj.price);
        ajaxCallback("saveBill",bill,function(){
            //showLoader("竞价提交成功!",true);
            changePage("billnew");
        });
    }else{
        showLoader("请先登陆!",true);
    }
}

function tijiaoyouke(){
    var tel = $("#infotel").val();
    var address = $("#infoaddress").val();
    var note = $("#infobeizhu").val();
    if($.trim(tel)=="" || $.trim(address)==""){
        showLoader("请填写电话和地址信息!",true);
        return;
    }
    if(tel.length<11){
        showLoader("请填写正确的电话号码!",true);
        return;
    }
    var bill = {};
    bill.shop = "";
    bill.sid = "";
    bill.gids = focusobj.id;
    bill.gnames = focusobj.gname;
    bill.total = focusobj.price;
    bill.tel = tel;
    bill.address = address;
    bill.note = note;
    ajaxCallback("saveBill",bill,function(){
        showLoader("竞价提交成功!",true);
        showTipTimer("竞价提交成功!",function(){
            toMyBill();
        });

    });
}

function youketijiao(){
    var type = $("#iscar").val();
    if(type == 1){
        tijiaoyouke();
    }else{
        tijiaocaryouke();
    }
}

function usertijiao(){
    var type = $("#iscar2").val();
    if(type == 1){
        tijiaouser()
    }else{
        tijiaocaruser();
    }
}

function addToCar(){
    var str = localStorage[gouwuche];
    var list = [];
    if(str){
        list = JSON.parse(str);
    }
    list.push(focusobj);
    localStorage[gouwuche] = JSON.stringify(list);
    showLoader("已经添加到购物车!",true);
}

function showCar(){
    changePage("carspage");
    carlist();
}

function carlist(){
    var str = localStorage[gouwuche];
    var list = [];
    if(str){
        list = JSON.parse(str);
    }
    $("#cars").refreshShowListView(list);
}

function removeCar(id){
    var str = localStorage[gouwuche];
    var list = [];
    var newlist = [];
    if(str){
        list = JSON.parse(str);
        for(var i=0;i<list.length;i++){
            var obj = list[i];
            if(obj.id == id){
                continue;
            }
            newlist.push(obj);
        }
        localStorage[gouwuche] = JSON.stringify(newlist);
        $("#cars").refreshShowListView(newlist);
    }
}

function tijiaocar(){
    if(userinfo){
        changePage("infopage2");
        $("#iscar2").val("2");
    }else{
        changePage("infopage");
        $("#iscar").val("2");
    }
}

function tijiaocaruser(){
    var note = $("#infobeizhu2").val();
    var str = localStorage[gouwuche];
    var sids = [];
    var shopgoods = {};
    var bills = [];
    if(str){
        var list = JSON.parse(str);
        for(var i=0;i<list.length;i++){
            var flag = false;
            var good = list[i];
            for(var n=0;n<sids.length;n++){
                if(sids[n]==good.sid){
                    shopgoods[good.sid].push(good);
                    flag = true;
                    break;
                }
            }
            if(!flag){
                shopgoods[good.sid] = [];
                shopgoods[good.sid].push(good);
                sids.push(good.sid);
            }
        }
    }

    for(var i=0;i<sids.length;i++){
        var goodlist = shopgoods[sids[i]];
        var gids = "";
        var gnames = "";
        var sname = "";
        var total = 0;
        var sid = sids[i];
        var bill = {};
        bill.uid = userinfo.id;
        bill.user = userinfo.username;
        for(var n=0;n<goodlist.length;n++){
            var good = goodlist[n];
            if(n==0){
                sname = good.shop;
                gids+=good.id;
                gnames+=good.gname;
            }else{
                gids+=","+good.id;
                gnames+=","+good.gname;
            }
            total+=parseInt(good.price);
        }
        bill.shop = sname;
        bill.sid = sid;
        bill.gids = gids;
        bill.gnames = gnames;
        bill.total = total;
        bill.tel = userinfo.tel || "";
        bill.address = userinfo.address || "";
        bill.note = note;
        bills.push(bill);
    }
    if(bills.length){
        ajaxCallback("saveBills",{bills:JSON.stringify(bills)},function(data){
            localStorage[gouwuche] = "";
            showTipTimer("竞价提交成功!",function(){
                toMyBill();
            });
        });
    }

}

function tijiaocaryouke(){
    var tel = $("#infotel").val();
    var address = $("#infoaddress").val();
    var note = $("#infobeizhu").val();
    if($.trim(tel)=="" || $.trim(address)==""){
        showLoader("请填写电话和地址信息!",true);
        return;
    }
    if(tel.length<11){
        showLoader("请填写正确的电话号码!",true);
        return;
    }
    var str = localStorage[gouwuche];
    var sids = [];
    var shopgoods = {};
    var bills = [];
    if(str){
        var list = JSON.parse(str);
        for(var i=0;i<list.length;i++){
            var flag = false;
            var good = list[i];
            for(var n=0;n<sids.length;n++){
                if(sids[n]==good.sid){
                    shopgoods[good.sid].push(good);
                    flag = true;
                    break;
                }
            }
            if(!flag){
                shopgoods[good.sid] = [];
                shopgoods[good.sid].push(good);
                sids.push(good.sid);
            }
        }
    }

    for(var i=0;i<sids.length;i++){
        var goodlist = shopgoods[sids[i]];
        var gids = "";
        var gnames = "";
        var sname = "";
        var total = 0;
        var sid = sids[i];
        var bill = {};
        bill.uid = "";
        bill.user = "";
        for(var n=0;n<goodlist.length;n++){
            var good = goodlist[n];
            if(n==0){
                sname = good.shop;
                gids+=good.id;
                gnames+=good.gname;
            }else{
                gids+=","+good.id;
                gnames+=","+good.gname;
            }
            total+=parseInt(good.price);
        }
        bill.shop = sname;
        bill.sid = sid;
        bill.gids = gids;
        bill.gnames = gnames;
        bill.total = total;
        bill.tel = tel;
        bill.address = address;
        bill.note = note;
        bills.push(bill);
    }
    if(bills.length){
        ajaxCallback("saveBills",{bills:JSON.stringify(bills)},function(data){
            localStorage[gouwuche] = "";
            showTipTimer("竞价提交成功!",function(){
                toMyBill();
            });
        });
    }

}



function toMyBill(){
    if(userinfo){
        changePage("mybillpage");
        mybillslist();
    }else{
        changePage("loginpage");
    }

}

function toNotice(){
    changePage("noticepage");
    listNotice();
}

function mybillslist(){
    ajaxCallback("mybills",{uid:userinfo.id},function(data){
        $("#bills").refreshShowListView(data);
    });
}
function noticeDetail(id){
    for(var i=0;i<noticelist.length;i++){
        if(id == noticelist[i].id){
            var obj = noticelist[i];
            changePage("noticedetailpage");
            $("#ntitle").text(obj.title);
            $("#nndate").text(obj.ndate);
            $("#nnote").text(obj.note);
            $("#noticeposter").attr("src",fileurl+obj.img);
        }
    }
}

function listNotice(){
    ajaxCallback("listNotice",{},function(data){
        noticelist = data;
        $("#notelist").refreshShowListView(data);
    });
}

function billDetail(id){

}
function tuiding(id){
    ajaxCallback("delBill",{bid:id},function(){
        ajaxCallback("mybills",{uid:userinfo.id},function(data){
            $("#bills").refreshShowListView(data);
        });
    });

}

function toAbout(){
    changePage("aboutpage");
}