/**
 * Created by ideabobo on 14-6-28.
 * commontools
 */
serializeObject = function(form) {
    var o = {};
    $.each(form.serializeArray(), function(index) {
        if (o[this['name']]) {
            o[this['name']] = o[this['name']] + "," + this['value'];
        } else {
            o[this['name']] = this['value'];
        }
    });
    return o;
};

function ajaxCallback(action, data, cb) {
    if(!clientUrl){
        alert("请先设置服务端根路径");
        return;
    }
    //showLoader("请稍后...");
    data = data || {};
    var retrytimes = 5;
    var count = 0;
    var connectServer = function(){
        //showLoader("请稍后...");
        $.ajax({
            type: "GET",
            url: clientUrl + action,
            dataType: "jsonp",
            jsonp: "callback",
            contentType: "text/html; charset=utf-8",
            data: data,
            timeout:50000,
            async:true,
            success: function (data) {
                hideLoader();
                cb(data);
                console.log("success");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                hideLoader();
                console.log("error:"+XMLHttpRequest+" textStatus:"+textStatus+" errorThrown"+errorThrown);
            },
            complete:function(XMLHttpRequest, textStatus){
                console.log("complete:"+XMLHttpRequest+"textStatus:"+textStatus);
                if(textStatus == "timeout"){
                    if(count<retrytimes){
                        count++;
                        connectServer();
                        console.log(count);
                    }else{
                        showLoader("连接服务器超时！",true);
                    }

                }
            }
        });
    };
    connectServer();
}

function showLoader(str,textonly){
    if(textonly){
        alert(str);
    }
}
function hideLoader(){

}
function changePage(elid){
    $(".page").hide();
    $("#"+elid).show();
}

function rrplace(tpl, colums, records, index) {
    index = index || 0;
    var int = tpl.indexOf("%s");
    if (int != -1) {
        var p = colums[index];
        var str = records[p];
        tpl = tpl.replace("%s", str);
        index++
        return rrplace(tpl, colums, records, index);
    } else {
        return tpl;
    }
}

$.fn.extend({
    refreshShowListView: function (records) {
        var attr = $(this).data("property");
        if (attr && records && records.length) {
            attr = JSON.parse(attr);
            var html = "";
            var tpl = attr.tpl;
            var colums = attr.colums;
            for (var i = 0; i < records.length; i++) {
                var li = rrplace(tpl, colums, records[i]);
                html += li;
            }
            $(this).html(html);
        } else {
            $(this).html("");
        }

    }
});
